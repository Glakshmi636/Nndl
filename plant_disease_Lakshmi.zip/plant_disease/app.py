from flask import Flask, render_template, request
import os

app = Flask(__name__)

# folder to save uploaded images
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_image():
    if 'image' not in request.files:
        return "No image uploaded!"

    file = request.files['image']

    if file.filename == "":
        return "No file selected!"

    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    return f"Image uploaded successfully! Saved at: {file_path}"

if __name__ == "__main__":
    app.run(debug=True)